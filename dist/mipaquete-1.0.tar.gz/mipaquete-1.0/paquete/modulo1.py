def funcion_1 ():
    print("estoy en el modulo 1")
