def funcion_2():
    print("estoy en el modulo2")
